Trabalho 1 da disciplina de Paradigmas de Programação

- Implementou-se, na linguagem Java, usando banco de dados relacional, todas as funções pedidas pela especificação do trabalho.

- Dependências:
    - JDK instalado
    - Servidor do banco de dados MySQL
    - IDE ou ambiente para execução

- Instruções:
    - Tendo as dependências anteriormente mencionadas instaladas, é necessário para a execução realizar a troca adequada dos dados de conexão da base de dados para o seu dispositivo (caminho, porta, user e senha).
    - Ademais, verifique o funcionamento do conector ao banco de dados (mysql-connector-j-8.4.0.jar), incluído no presente .zip.